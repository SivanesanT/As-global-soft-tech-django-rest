from django.urls import include, path
from .views import *

urlpatterns = [
    path('member/', MymemberView.as_view()),
    path('member/<int:pk>/', MymemberView.as_view()),
    path('register/',registerUser.as_view()),    
    path('login/', LoginUser.as_view()),
]
